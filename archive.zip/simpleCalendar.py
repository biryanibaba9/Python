import calendar

c = calendar.TextCalendar(calendar.SUNDAY)
st = c.formatmonth(2018, 4 , 0, 0)
print(st)