def numberRange():
	x = int(raw_input('Enter a number: '))
	rnd = 0
	print rnd
	for rnd in range(x):
		print (rnd+1)			

numberRange()